<?php

namespace thebookshelf;

use Illuminate\Database\Eloquent\Model;

class College extends Model
{
    //
}
