<?php

namespace thebookshelf;

use Illuminate\Database\Eloquent\Model;

class Book_field extends Model
{
    //
}
