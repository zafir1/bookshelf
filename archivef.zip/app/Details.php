<?php

namespace thebookshelf;

use Illuminate\Database\Eloquent\Model;

class Details extends Model
{
    protected $guarded = [];
}
