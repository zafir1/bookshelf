<?php

namespace thebookshelf\Http\Controllers;

use thebookshelf\details;
use Illuminate\Http\Request;

class DetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \thebookshelf\details  $details
     * @return \Illuminate\Http\Response
     */
    public function show(details $details)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \thebookshelf\details  $details
     * @return \Illuminate\Http\Response
     */
    public function edit(details $details)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \thebookshelf\details  $details
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, details $details)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \thebookshelf\details  $details
     * @return \Illuminate\Http\Response
     */
    public function destroy(details $details)
    {
        //
    }
}
