<?php

namespace thebookshelf;

use Illuminate\Database\Eloquent\Model;

class UserInterest extends Model
{
    
}
