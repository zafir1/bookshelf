<?php $__env->startSection('title','Add Book | TheBookShelf'); ?>
<?php $__env->startSection('content'); ?>

    <div class="h3">
        Add Book
    </div>
	
	<form action="<?php echo e(route('book.store')); ?>" method="post">
		<?php echo csrf_field(); ?>
		<div class="row mt-3">
			<div class="col-md-8">
				<div class="form-group">
					<div class="mb-0 "> <label for="name"><b>Book Name:</b></label> </div>
					<input type="text" name="name" value="<?php echo e(old('name')); ?>" id="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" placeholder="Type book name.." autocomplete="off" >
					<small class="<?php echo e($errors->has('name') ? 'text-danger' : 'form-text text-muted'); ?>">
						<?php echo e($errors->has('name') ? $errors->first('name') : "Enter a valid BookName"); ?>

					</small>
				</div>
				
				
				
				
				
				<div class="row">
					<div class="col-md-7">
						<div class="form-group">
							<div class="mb-0 "> <label for="author"><b>Author :</b></label> </div>
							<input type="text" name="author" id="author" class="form-control" placeholder="Type author name.." autocomplete="off" value="<?php echo e(old('author')); ?>">
							<small class="<?php echo e($errors->has('author') ? 'text-danger' : 'form-text text-muted'); ?>">
								<?php echo e($errors->has('author') ? $errors->first('author') : ""); ?>

							</small>
						</div>
					</div>

					<div class="col-md-5">
						<div class="form-group">
							<div class="mb-0 "> <label for="publication"><b>Publication:</b></label> </div>
							<input type="text" name="publication" id="publication" class="form-control" placeholder="Type publication name.." autocomplete="off" value="<?php echo e(old('publication')); ?>">
							<small class="<?php echo e($errors->has('publication') ? 'text-danger' : 'form-text text-muted'); ?>">
								<?php echo e($errors->has('publication') ? $errors->first('publication') : ""); ?>

							</small>
						</div>
					</div>
				</div>
				
				



				
				
				
				
				<div class="row">
					<div class="col-md-3">
						<div class="form-group">
							<div class="mb-0 "> <label for="price"><b>Price :</b></label> </div>
							<input type="number" name="price" id="price" class="form-control" placeholder="Book price..." autocomplete="off" value="<?php echo e(old('price')); ?>">
							<small class="<?php echo e($errors->has('price') ? 'text-danger' : 'form-text text-muted'); ?>">
								<?php echo e($errors->has('price') ? $errors->first('price') : ""); ?>

							</small>
						</div>
					</div>

					<div class="col-md-9">
						<div class="form-group">
							<div class="mb-0 "> <label for="edition"><b>Eidtion :</b></label> </div>
							<input type="text" name="edition" id="edition" class="form-control" placeholder="Enter price of books.." autocomplete="off" value="<?php echo e(old('edition')); ?>">
							<small class="<?php echo e($errors->has('edition') ? 'text-danger' : 'form-text text-muted'); ?>">
								<?php echo e($errors->has('edition') ? $errors->first('edition') : ""); ?>

							</small>
						</div>
					</div>
				</div>
				
			<input type="submit" value="Add Book" class="btn btn-success form-control">
			</div>

			<div class="col-md-4 mt-3">
				<div class="h5 text-primary" >
					Book is related to:
				</div>
				<?php if($errors->has('checkbox')): ?>
					<small class="text-danger"><b>Please Choose at least 3 fields</b></small>
				<?php endif; ?>
				<?php echo $__env->make('interest.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<a href="<?php echo e(url('interest')); ?>" class="btn btn-primary form-control mt-3">Add new Field</a>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/books/create.blade.php ENDPATH**/ ?>