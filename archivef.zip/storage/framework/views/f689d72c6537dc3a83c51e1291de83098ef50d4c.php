<div class="form-check">
  <input class="form-check-input <?php echo e($errors->has('checkbox') ? 'is-invalid' : ''); ?>" name="checkbox[]" type="checkbox"  value="<?php echo e($checkbox->id); ?>" id="<?php echo e($checkbox->id); ?>">
  <label class="form-check-label" for="<?php echo e($checkbox->id); ?>">
    <b><?php echo e($checkbox->field); ?></b>
  </label>
</div><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/interest/list.blade.php ENDPATH**/ ?>