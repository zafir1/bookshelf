<form action="<?php echo e(url('booksearch')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="form-group col-md-9">
			<input type="text" name="search" value="<?php echo e(old('search')); ?>" class="form-control" placeholder="Search your book here...">
		</div>
		<div class="col-md-3">
			<button type="submit" class="form-control"><i class="fas fa-search"> Search</i></button>
		</div>
	</div>
</form><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/books/search.blade.php ENDPATH**/ ?>