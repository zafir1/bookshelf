<div class="form-check">
  <input class="form-check-input" name="checkbox[]" <?php echo e(Auth::user()->isInterested($checkbox->id,$userInterest) ? 'checked' : ''); ?> type="checkbox"  value="<?php echo e($checkbox->id); ?>" id="<?php echo e($checkbox->id); ?>">
  <label class="form-check-label" for="<?php echo e($checkbox->id); ?>">
    <?php echo e($checkbox->field); ?>

  </label>
</div><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/forms/checkbox.blade.php ENDPATH**/ ?>