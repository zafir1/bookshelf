<div class="col-<?php echo e($device); ?>-<?php echo e($size); ?> mb-2 mt-2 p-3">
	<div class="card">
		<a href="<?php echo e(route('book.show',$book->id)); ?>">
			<div class="card-header">
				<b class="text-primary"><i class="fas fa-book"></i> <?php echo e($book->name); ?></b>
			</div>
		</a>
		<div class="card-body">
			<table class="table table-striped">
				<tr>
					<td><b>Author Name: </b></td>
					<td><?php echo e($book->author); ?></td>
				</tr>
				<tr>
					<td><b>Publication: </b></td>
					<td><?php echo e($book->publication); ?></td>
				</tr>
				<tr>
					<td><b>Price: </b></td>
					<td><?php echo e($book->price); ?></td>
				</tr>
				<tr>
					<td><b>Edition: </b></td>
					<td><?php echo e($book->edition); ?></td>
				</tr>
			</table>
			<div class="float-right">
				<a href="" class="btn btn-success">View</a>
			</div>
		</div>
	</div>
</div><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/books/block.blade.php ENDPATH**/ ?>