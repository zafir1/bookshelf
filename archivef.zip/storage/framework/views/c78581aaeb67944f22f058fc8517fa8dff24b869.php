<?php $__env->startSection('title','TheBookShelf | Fill Basic Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-8">
		<form action="<?php echo e(url('basic')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<div class="form-group mb-4">
				<b class="mb-2">College: </b>
				<select name="college" class="form-control" id="exampleFormControlSelect1 col-lg-6">
					<?php $__currentLoopData = $colleges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $college): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($college->id); ?>"><?php echo e($college->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group mb-4">
				<b class="mb-2">Department: </b>
				<select name="department" class="form-control" id="exampleFormControlSelect1 col-lg-6">
					<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group mb-4">
				<b class="mb-2">Location: </b>
				<select name="location" class="form-control" id="exampleFormControlSelect1 col-lg-6">
					<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group mb-4">
				<b class="mb-2">Contact: </b>
				<input name="contact" type="number" placeholder="Enter your Contact number..." class="form-control">
			</div>
			<input class="btn btn-success float-right" type="submit" name="submit" value="Update">
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/user/basics.blade.php ENDPATH**/ ?>