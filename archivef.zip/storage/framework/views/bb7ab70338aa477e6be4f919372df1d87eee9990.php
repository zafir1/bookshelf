<?php $__env->startSection('title'); ?>
	<?php echo e($book->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="h4"><?php echo e($book->name); ?></div>
	<div class="row">
		<div class="col-md-6">
			<?php echo e($book->author); ?>

		</div>
	</div>

	<div class="col-md-12" align="">
		<?php echo $book_details->description; ?>

	</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/books/show.blade.php ENDPATH**/ ?>