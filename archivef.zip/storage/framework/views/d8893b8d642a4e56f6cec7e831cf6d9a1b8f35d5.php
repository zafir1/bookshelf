<?php if(Session::has('info')): ?>
	<div class="alert alert-info" role="alert">
		<?php echo e(Session::get('info')); ?>

	</div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
	<div class="alert alert-success" role="alert">
		<?php echo e(Session::get('success')); ?>

	</div>
<?php endif; ?>

<?php if(Session::has('danger')): ?>
	<div class="alert alert-danger" role="alert">
		<?php echo e(Session::get('danger')); ?>

	</div>
<?php endif; ?><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/layouts/partials/alerts.blade.php ENDPATH**/ ?>