<?php $__env->startSection('content'); ?>

    <div class="row">
		<div class="col-md-6">
			<h4>Books For you!</h4>
		</div>
		<div class="col-md-6">
			<?php echo $__env->make('books.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
    </div>

    <div class="row">
    	<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<?php echo $__env->make('books.block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/home.blade.php ENDPATH**/ ?>