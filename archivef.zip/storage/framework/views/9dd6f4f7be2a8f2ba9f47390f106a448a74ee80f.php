<?php $__env->startSection('content'); ?>
	<form action="<?php echo e(url('add_new_interest')); ?>" method="post" class="form-group">
		<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col-md-10 mb-3">
				<input type="text" class="form-control" value="<?php echo e(old('field')); ?>" name="field" placeholder="Add a new field of interest...">
				<?php if($errors->has('field')): ?>
					<small class="text-danger"><?php echo e($errors->first('field')); ?></small>
				<?php endif; ?>
			</div>
			<div class="col-md-2">
				<input type="submit" class="btn btn-success form-control" value="Add new field">
			</div>
		</div>
	</form>

	<hr>

	<h4>Please Select some of your field of interests..</h4>
	<form action="<?php echo e(url('submit_user_interest')); ?>" method="post">
		<?php echo csrf_field(); ?>
		<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo $__env->make('forms.checkbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="form-group mt-5 p-4">
			<input type="submit" value="submit interests" class="form-control btn btn-success float-right">
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zafir/projects/websites/bookshelf/resources/views/user/interest.blade.php ENDPATH**/ ?>