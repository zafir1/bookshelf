@foreach($fields as $checkbox)
	@include('interest.list')
@endforeach