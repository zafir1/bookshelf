<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use thebookshelf\Department;
use Faker\Generator as Faker;

$factory->define(Department::class, function (Faker $faker) {
    return [
        //
    ];
});
