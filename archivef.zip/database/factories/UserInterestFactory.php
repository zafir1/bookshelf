<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use thebookshelf\UserInterest;
use Faker\Generator as Faker;

$factory->define(UserInterest::class, function (Faker $faker) {
    return [
        //
    ];
});
