<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use thebookshelf\Location;
use Faker\Generator as Faker;

$factory->define(Location::class, function (Faker $faker) {
    return [
        //
    ];
});
