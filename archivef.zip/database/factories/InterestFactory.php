<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use thebookshelf\Interest;
use Faker\Generator as Faker;

$factory->define(Interest::class, function (Faker $faker) {
    return [
        //
    ];
});
